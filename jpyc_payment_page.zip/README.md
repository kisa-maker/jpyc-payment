# JPYC 支払いページ

このページでは、Metamaskを使ってAvalancheネットワーク上のJPYCトークンを送金できます。

## 💡 使い方

1. Metamask（スマホアプリ）を開く  
2. 左上のメニューから「ブラウザ」を選択  
3. このページのURLを貼り付けて開く  
4. 「Metamaskを接続」→「送金金額を入力」→「Metamaskで支払う」ボタンをタップ

## ⚙️ 技術情報

- ネットワーク: Avalanche (Chain ID 43114)  
- トークン: JPYC  
- JPYCコントラクト: `0x431D5dfF03120AFA4bDf332c61A6e1766eF37BDB`  
- 受取アドレス: `0xead0e649faa6017adcfed52ef4eb39a1a12e4b5b`  

---

Created by ChatGPT for Kisa Okabe
